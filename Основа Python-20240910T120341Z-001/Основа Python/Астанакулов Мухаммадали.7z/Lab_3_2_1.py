def chek_int(*args: list) -> bool:
    for i in range(len(args)):
        arg = args[i]
        for j in range(len(arg)):
            mapped_numbers = list(map(lambda x: type(x) == int, arg[j]))
            return(all(mapped_numbers))
    return True
            
def args_chek(*args: list) -> bool:
    if chek_int(args) == False:
        return("Ощибка")
    for i in range(len(args)):
        for j in range(i + 1, len(args)):
            if any(item in args[i] for item in args[j]):
                return False
    return True


print(args_chek([1, 1, 3], [4, 5, 6]))

print(args_chek([1, 2, 3], [3, 4, 6]))

print(args_chek([1, 2, 3], [4, 5, 6], [6, 8, 7]))
