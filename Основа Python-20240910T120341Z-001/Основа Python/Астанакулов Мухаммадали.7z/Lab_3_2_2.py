def binom(n: int) -> str:
    if n == 0:
        result = "1"
    elif n < 0:
        result = "1/(" + binom(-n) + ")"
    else:
        result = ""
        for i in range(n + 1):
            if i > 0:
                result += "+"
            coeff = 1
            for j in range(i):
                coeff *= (n - j) // (j + 1)
            if coeff > 1:
                result += str(coeff)
            if n - i > 0:
                result += "a"
                if n - i > 1:
                    result += "^" + str(n - i)
            if i > 0:
                result += "b"
                if i > 1:
                    result += "^" + str(i)
    return result


n = input()
if n.isnumeric():
    print(binom(int(n)))
else:
    print("Ощибка")
