def hofstadter_q(n: int): 
    q = [1, 1]
    for i in range(0, n):
        if i < 2:
            yield 1
        else:
            next_q = q[i - q[i - 1]] + q[i - q[i - 2]]
            q.append(next_q)
            yield next_q

n = int(input())
if n>0:
    print(list(hofstadter_q(n)))
