import numpy as np
import threading
import concurrent.futures
import time

N = 1000
P = np.random.rand(N)
Q = np.random.rand(N)
R = np.zeros((N, N))

# Функция для вычисления строки матрицы R
def calculate_row(i):
    global R
    for j in range(N):
        distance = np.linalg.norm(Q[j] - P[i])
        R[i, j] = 1 / (1 + distance)

# Без использования concurrent.futures
start_time = time.time()

threads = []
for i in range(N):
    thread = threading.Thread(target=calculate_row, args=(i,))
    threads.append(thread)

for thread in threads:
    thread.start()

for thread in threads:
    thread.join()

end_time = time.time()
print(f"Время выполнения без concurrent.futures: {end_time - start_time} сек.")

# Используя concurrent.futures
start_time = time.time()

with concurrent.futures.ThreadPoolExecutor() as executor:
    executor.map(calculate_row, range(N))

end_time = time.time()
print(f"Время выполнения с concurrent.futures: {end_time - start_time} сек.")

