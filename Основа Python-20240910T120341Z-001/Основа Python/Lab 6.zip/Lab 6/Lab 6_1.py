import threading
import time

print("№ Варианта = студ_номер % 5 +1 :", 10020995 % 5 + 1)
# Создаем семафор с максимальным значением 2
semaphore = threading.Semaphore(100)


def worker(thread_id):
    print(f"Поток {thread_id} ожидает доступа.")

    # Поток пытается захватить семафор
    with semaphore:
        print(f"Поток {thread_id} получил доступ.")
        time.sleep(2)  # Имитация долгой задачи
        print(f"Поток {thread_id} освободил доступ.")


# Создаем 5 потоков
threads = []
for i in range(7):
    thread = threading.Thread(target=worker, args=(i,))
    threads.append(thread)

# Запускаем потоки
for thread in threads:
    thread.start()

# Ждем завершения всех потоков
for thread in threads:
    thread.join()

print("Главный поток завершен.")
