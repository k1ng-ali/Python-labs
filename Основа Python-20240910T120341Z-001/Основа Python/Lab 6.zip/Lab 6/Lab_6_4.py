print(10020995 % 3 + 1)

import os
import concurrent.futures
import time

def count_files(directory):
    file_count = sum([len(files) for _, _, files in os.walk(directory)])
    return file_count

def process_directory(directory):
    file_count = count_files(directory)
    with open(os.path.join(directory, 'size.txt'), 'w') as file:
        file.write(str(file_count))

def single_threaded_execution(current_directory, subdirectories):
    start_time = time.time()

    for subdir in subdirectories:
        process_directory(os.path.join(current_directory, subdir))

    end_time = time.time()
    return end_time - start_time

def multi_threaded_execution(current_directory, subdirectories):
    start_time = time.time()

    with concurrent.futures.ThreadPoolExecutor() as executor:
        futures = [executor.submit(process_directory, os.path.join(current_directory, subdir)) for subdir in subdirectories]
        concurrent.futures.wait(futures)

    end_time = time.time()
    return end_time - start_time

if __name__ == "__main__":
    # Получение текущей директории
    current_directory = os.getcwd()

    # Получение списка поддиректорий
    subdirectories = [d for d in os.listdir(current_directory) if os.path.isdir(os.path.join(current_directory, d))]

    # Создание файла size.txt для текущей директории
    process_directory(current_directory)

    # Выполнение в одном потоке
    single_threaded_time = single_threaded_execution(current_directory, subdirectories)
    print(f"Время выполнения в одном потоке: {single_threaded_time} сек.")

    # Выполнение в нескольких потоках
    multi_threaded_time = multi_threaded_execution(current_directory, subdirectories)
    print(f"Время выполнения в нескольких потоках: {multi_threaded_time} сек.")
