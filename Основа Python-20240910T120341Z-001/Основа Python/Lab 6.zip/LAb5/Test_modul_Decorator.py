import unittest
from Lab5 import RemembersDecorator, ObjNew, InvalidDataError


class TestRemembersDecorator(unittest.TestCase):
    def setUp(self):
        self.members_decorator = RemembersDecorator(ObjNew)

    def test_add_object(self):
        obj = self.members_decorator("test_object", n=5, price=10.0)
        self.assertEqual(obj.name, "test_object")
        self.assertEqual(obj.n, 5)
        self.assertEqual(obj.price, 10.0)

    def test_duplicate_object(self):
        # Первый вызов должен быть успешным
        self.members_decorator("test_object", n=5, price=10.0)

        # Второй вызов должен вызвать ValueError и внутри него должно быть InvalidDataError
        with self.assertRaises(ValueError, msg="Должно возникнуть исключение ValueError"):
            self.members_decorator("test_object", n=3, price=12.0)


if __name__ == '__main__':
    unittest.main()


