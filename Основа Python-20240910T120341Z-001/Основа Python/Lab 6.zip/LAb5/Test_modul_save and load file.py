import unittest
import os
from Lab5 import save_data, load_data

class TestDataFunctions(unittest.TestCase):
    def setUp(self):
        self.filename = "test_data.pkl"
        self.data = {"test_object": {'quantity': 5, 'price': 10.0}}

    def test_save_and_load_data(self):
        save_data(self.data, self.filename)
        loaded_data = load_data(self.filename)
        self.assertEqual(loaded_data, self.data)

    def tearDown(self):
        if os.path.exists(self.filename):
            os.remove(self.filename)

if __name__ == '__main__':
    unittest.main()
