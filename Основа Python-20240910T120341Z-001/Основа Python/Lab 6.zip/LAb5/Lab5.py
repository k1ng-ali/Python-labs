import csv
import pickle

class InvalidDataError(Exception):
    pass




class InvalidObjectError(Exception):
    def __init__(self, message="Недопустимый объект"):
        self.message = message
        super().__init__(self.message)

class RemembersDecorator:
    def __init__(self, name, n=1):
        self._name = name
        self._n = n
        self._members = {}

    def __call__(self, *args, **kwargs):
        obj = args
        try:
            if obj in self._members:
                raise ValueError(f"Объект с именем {args[0]} уже существует!")
            instance = self._name(*args, **kwargs)
            self._members[obj] = instance
            return instance
        except ValueError as e:
            raise InvalidObjectError(f"Было вызвано исключение: {e}")

    def get_members(self):
        return self._members

    def __getstate__(self):
        return {'_name': self._name, '_n': self._n, '_members': self._members}

    def __setstate__(self, state):
        self._name = state['_name']
        self._n = state['_n']
        self._members = state['_members']

    def call(self, *args, **kwargs):
        obj = args
        try:
            if obj in self._members:
                raise ValueError(f"Объект с именем {args[0]} уже существует!")
            instance = self._name(*args, **kwargs)
            self._members[obj] = instance
            return instance
        except ValueError as e:
            raise InvalidDataError(f"Было вызвано исключение: {e}")



class Test:
    def __init__(self):
        self._name = None

    def what_is(self):
        print(f"Этот объект называется {self._name}")
        self._name = "book"


class Test2(Test):
    def __init__(self, name, n=1, color="dark"):
        super().__init__()
        self._color = color
        self._n = n

    def display_info(self):
        print(self._name, "Существует", self._n, "штук", self._color)

    def __repr__(self):
        return f"Test2(name={self._name}, n={self._n}, color={self._color})"


@RemembersDecorator
class ObjNew(Test):
    def __init__(self, name, n=1, price=0):
        super().__init__()
        self._name = name
        self._n = n
        self._price = price

    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, name):
        self._name = name

    @property
    def n(self):
        return self._n

    @n.setter
    def n(self, n):
        if n > 0:
            self._n = n
        else:
            raise ValueError("Введите число больше 0")

    @property
    def price(self):
        return self._price

    @price.setter
    def price(self, price):
        if price >= 0:
            self._price = price
        else:
            raise ValueError("Цена не может быть отрицательной")

    def __mul__(self, other):
        self._n = self._n * other

    def display_info(self):
        print(self._name, "Существует", self._n, "штук")

    def __repr__(self):
        return f"ObjNew(name={self._name}, n={self._n})"


import csv


def save_data(data, filename):
    try:
        with open(filename, 'w', newline='') as file:
            writer = csv.writer(file)
            for key, value in data.items():
                writer.writerow([key, value['quantity'], value['price']])
    except FileNotFoundError as e:
        raise InvalidDataError(f"Ошибка при сохранении данных: {e}")

def load_data(filename):
    try:
        data = {}
        with open(filename, 'r') as file:
            reader = csv.reader(file)
            for row in reader:
                key, quantity, price = row
                data[key] = {'quantity': int(quantity), 'price': float(price)}
        return data
    except (FileNotFoundError, ValueError) as e:
        raise InvalidDataError(f"Ошибка при чтении данных: {e}")

class Menu:
    def __init__(self):
        self.members_decorator = RemembersDecorator(ObjNew)
        self.data_filename = "data.csv"
        self.members_data = {}  # Добавлен словарь для хранения данных

    def add_object(self):
        try:
            name = input("Введите имя объекта: ")

            # Проверяем, существует ли объект с таким именем
            if name in self.members_data:
                raise ValueError(f"Объект с именем {name} уже существует!")

            n = int(input("Введите количество объектов: "))
            price = float(input("Введите цену на один объект: "))

            obj = self.members_decorator(name, n=n, price=price)
            print(f"Объект {obj.name} добавлен.")

            # Добавляем данные в словарь
            self.members_data[obj.name] = {'quantity': obj.n, 'price': obj.price}
        except (ValueError, InvalidObjectError) as e:
            print(f"Ошибка: {e}")
    def save_data(self):
        try:
            # Сохраняем данные из словаря в файл
            save_data(self.members_data, self.data_filename)
            print("Данные сохранены.")
        except InvalidDataError as e:
            print(f"Ошибка при сохранении данных: {e}")

    def load_data(self):
        try:
            # Загружаем данные из файла в словарь
            self.members_data = load_data(self.data_filename)
            print("Данные загружены.")
        except InvalidDataError as e:
            print(f"Ошибка при загрузке данных: {e}")

    def update_object(self):
        try:
            name = input("Введите имя объекта для обновления: ")

            # Проверяем, существует ли объект с таким именем
            if name not in self.members_data:
                raise ValueError(f"Объект с именем {name} не существует!")

            # Выводим текущую информацию о объекте
            current_quantity = self.members_data[name]['quantity']
            current_price = self.members_data[name]['price']
            print(f"Текущее количество: {current_quantity}, Текущая цена: {current_price}")

            # Запрашиваем новые значения
            new_quantity = int(input("Введите новое количество: "))
            new_price = float(input("Введите новую цену за штуку: "))

            # Обновляем данные
            self.members_data[name]['quantity'] = new_quantity
            self.members_data[name]['price'] = new_price

            print(f"Данные для объекта {name} обновлены.")
        except (ValueError, InvalidDataError) as e:
            print(f"Ошибка: {e}")

    def display_objects(self):
        for name, data in self.members_data.items():
            quantity = data['quantity']
            price_per_unit = data['price']
            total_price = quantity * price_per_unit
            print(
                f"Имя: {name}, Количество: {quantity}, Цена за штуку: {price_per_unit} ₽, Общая стоимость: {total_price} ₽")

    def run(self):
        # Загрузка данных при запуске программы
        self.load_data()

        while True:
            print("\nМеню:")
            print("1. Добавить объект")
            print("2. Обновить данные объекта")
            print("3. Вывести данные об объектах")
            print("4. Сохранить данные")
            print("5. Выйти")

            choice = input("Выберите действие (1-5): ")

            if choice == '1':
                self.add_object()
            elif choice == '2':
                self.update_object()
            elif choice == '3':
                self.display_objects()
            elif choice == '4':
                self.save_data()
            elif choice == '5':
                # Сохраняем данные при выходе из программы
                self.save_data()
                print("Выход из программы.")
                break
            else:
                print("Неверный ввод. Пожалуйста, выберите от 1 до 5.")


if __name__ == "__main__":
    menu = Menu()
    menu.run()
