import unittest
from Lab5 import RemembersDecorator, ObjNew, InvalidDataError


class TestObjNew(unittest.TestCase):
    def setUp(self):
        # Создаем декоратор
        self.members_decorator = RemembersDecorator(ObjNew)

    def test_create_object(self):
        # Добавляем объект в декоратор
        self.members_decorator("test_object", n=5, price=10.0)

        # Создаем объект с тем же именем
        obj = self.members_decorator.get_members()[("test_object",)]

        # Проверяем значения
        self.assertEqual(obj.name, "test_object")
        self.assertEqual(obj.n, 5)
        self.assertEqual(obj.price, 10.0)


if __name__ == '__main__':
    unittest.main()
