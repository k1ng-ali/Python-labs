import ssl
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# Ваши учетные данные
email_login = "Hoangsang1982003@gmail.com"
email_password = "sang1982003@"

# Создание соединения с почтовым сервером Gmail
smtp_server = "smtp.gmail.com"
smtp_port = 587
context = ssl.create_default_context()

with smtplib.SMTP(smtp_server, smtp_port) as server:
    server.starttls(context=context)
    server.login(email_login, email_password)

    # Ваш код для отправки электронной почты здесь
