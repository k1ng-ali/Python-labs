import socket

def send_request(email, message):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect(('localhost', 12345))
        data = f"{email}\n{message}"
        s.sendall(data.encode('utf-8'))
        response = s.recv(1024).decode('utf-8')
        return response

def main():
    while True:
        email = input("Enter your email: ")
        message = input("Enter your message: ")

        response = send_request(email, message)
        print(response)

        if response == "OK":
            break

if __name__ == "__main__":
    main()
