import socket
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.utils import formatdate
import logging
import os
import time
import random
from dotenv import load_dotenv

load_dotenv()

# Чтение параметров из .env
ADMIN_EMAIL = os.getenv("EMAIL_LOGIN")
ADMIN_PASSWORD = os.getenv("EMAIL_PASSWORD")
IMAP_HOST = os.getenv("IMAP_HOST")
IMAP_PORT = int(os.getenv("IMAP_PORT"))
SMTP_HOST = os.getenv("SMTP_HOST")
SMTP_PORT = int(os.getenv("SMTP_PORT"))

# Установка параметров логгирования
logging.basicConfig(filename='server.log', level=logging.INFO, format='%(asctime)s - %(levelname)s: %(message)s')


def send_email(to, subject, body):
    msg = MIMEMultipart()
    msg['From'] = ADMIN_EMAIL
    msg['To'] = to
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))

    try:
        server = smtplib.SMTP(SMTP_HOST, SMTP_PORT)
        server.starttls()
        server.login(ADMIN_EMAIL, ADMIN_PASSWORD)
        server.sendmail(ADMIN_EMAIL, to, msg.as_string())
        server.quit()
        return True
    except Exception as e:
        logging.error(f"Error sending email: {str(e)}")
        return False


def validate_email(email):
    # Реализуйте валидацию email
    # Верните True, если email корректен, иначе False
    return True


def validate_message(message):
    # Реализуйте валидацию текста сообщения
    # Верните True, если текст корректен, иначе False
    return True


def process_request(client_socket):
    data = client_socket.recv(1024).decode('utf-8').split("\n")
    email, message = data[0], data[1]

    if not validate_email(email) or not validate_message(message):
        client_socket.send("Error: Invalid email or message".encode('utf-8'))
        logging.error(f"Invalid request from {client_socket.getpeername()}")
    else:
        unique_id = random.randint(10000, 99999)
        subject = f"[Your code: #{unique_id}]; Mailer"

        if send_email(email, subject, message):
            client_socket.send("OK".encode('utf-8'))
            logging.info(f"Request processed successfully. ID: {unique_id}")
        else:
            client_socket.send("Error: Email sending failed".encode('utf-8'))
            logging.error(f"Error sending email to {email}")


def main():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('localhost', 12345))
    server_socket.listen(1)

    while True:
        client_socket, addr = server_socket.accept()
        logging.info(f"Connection from {addr}")
        process_request(client_socket)
        client_socket.close()


if __name__ == "__main__":
    main()
