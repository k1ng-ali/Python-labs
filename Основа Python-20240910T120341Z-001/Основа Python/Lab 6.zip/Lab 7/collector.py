import imaplib
import email
from email.header import decode_header
import time
import logging
import os
from dotenv import load_dotenv

load_dotenv()

# Чтение параметров из .env
ADMIN_EMAIL = os.getenv("EMAIL_LOGIN")
ADMIN_PASSWORD = os.getenv("EMAIL_PASSWORD")
IMAP_HOST = os.getenv("IMAP_HOST")
IMAP_PORT = int(os.getenv("IMAP_PORT"))

# Установка параметров логгирования
logging.basicConfig(filename='collector.log', level=logging.INFO, format='%(asctime)s - %(levelname)s: %(message)s')

def process_email(msg):
    subject, encoding = decode_header(msg["Subject"])[0]
    if isinstance(subject, bytes):
        subject = subject.decode(encoding)

    if subject.startswith("[Ticket #"):
        logging.info(f"Success request. ID: {subject.split('#')[1][:-1]}")
        with open("success_request.log", "a") as file:
            file.write(f"ID: {subject.split('#')[1][:-1]}\n{msg.get_payload(decode=True).decode('utf-8')}\n\n")
    else:
        logging.error(f"Error request. Subject: {subject}")
        with open("error_request.log", "a") as file:
            file.write(f"Subject: {subject}\n{msg.get_payload(decode=True).decode('utf-8')}\n\n")

def check_emails():
    try:
        mail = imaplib.IMAP4_SSL(IMAP_HOST, IMAP_PORT)
        mail.login(ADMIN_EMAIL, ADMIN_PASSWORD)
        mail.select("inbox")

        _, messages = mail.search(None, "ALL")
        messages = messages[0].split()

        for msg_id in messages:
            _, msg_data = mail.fetch(msg_id, "(RFC822)")
            msg = email.message_from_bytes(msg_data[0][1])

            process_email(msg)

            # Удаление обработанных писем
            mail.store(msg_id, '+FLAGS', '(\Deleted)')
        mail.expunge()
        mail.close()
        mail.logout()
    except Exception as e:
        logging.error(f"Error checking emails: {str(e)}")

def main():
    period_check = int(os.getenv("PERIOD_CHECK"))
    while True:
        check_emails()
        time.sleep(period_check)

if __name__ == "__main__":
    main()
