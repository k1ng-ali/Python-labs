import time


def times_in_seconds(*times):
    list = times[0].split(":")
    t = int(list[0]) * 3600 + int(list[1]) * 60 + int(list[2])
    return t


def nearest_time(*times):
    t = time.localtime()
    console_time = time.strftime("%H:%M:%S", t)
    list_cons_time = times_in_seconds(str(console_time))
    output_time = times[0]
    for i in range(len(times)):
        if abs(list_cons_time - times_in_seconds(times[i])) < abs(list_cons_time - times_in_seconds(output_time)):
            output_time = times[i]
    return output_time

print(nearest_time("23:52:00", "21:00:59"))
print(nearest_time("21:22:33", "00:15:20", "14:47:50"))
print(nearest_time("23:55:00", "12:00:00", "23:45:00" ))
print(nearest_time("23:45:00", "23:55:00", "12:00:00"))