def hofstadter_q(n):
    q = [1, 1]
    if n == 1:
        list = "1"
    else:
        list = "1, 1"

    for i in range(2, n):
        next_q = q[i - q[i - 1]] + q[i - q[i - 2]]
        q.append(next_q)
        list += ", " + str(next_q)
    return list

n = int(input())
if n>0:
    print(hofstadter_q(n))
