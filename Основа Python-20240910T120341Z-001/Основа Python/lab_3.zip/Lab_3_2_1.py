def args_chek(*args):
    for i in range(len(args)):
        for j in range(i + 1, len(args)):
            if any(item in args[i] for item in args[j]):
                return False
    return True


print(args_chek([1, 2, 3], [4, 5, 6]))

print(args_chek([1, 2, 3], [3, 4, 6]))

print(args_chek([1, 2, 3], [4, 5, 6], [6, 8, 7]))