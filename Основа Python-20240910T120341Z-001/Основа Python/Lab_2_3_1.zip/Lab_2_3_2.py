from ipaddress import ip_address
import re

def normalize_ipv6_1(address_1):
    parts = address_1.split(":")
    list = ""
    for i in range(len(parts)):
        part_n: str = parts[i]
        if part_n == "":
            part_n="0"
        if (part_n) == "0000":
            part_n = "0"
        elif (part_n[0:3])=="000":
            part_n = part_n[3]
        elif (part_n[0:2])=="00":
            part_n=part_n[2:4]
        elif (part_n[0]) == "0":
            part_n=part_n[1:4]
        else:
            part_n=part_n
        list += str(part_n)+":"         
    return list[:-1]

def normalizer_ipv6_2(address_2):
    parts = address_2.split(":")
    list = ""
    i=0
    k=0 
    f=0
    while(i<len(parts)):
        if (parts[i]=="0" and parts[i-1]!="0"):
            k = i
        if (parts[i]=="0" and (i+1)!=len(parts)):
            if (parts[i]=="0" and parts[i-1]=="0" and parts[i+1]!="0"):
                f=i
                break
        if (parts[i]=="0" and (i+1)==len(parts)):
            if (parts[i]=="0" and parts[i-1]=="0"):
                f=i
                break            
        i += 1
    if (f>0):
        for i in range(k):
            list += parts[i] + ":"
        for i in range(f,len(parts)):
            if ((f+1)==len(parts)):
                list += ":"
            if (parts[0]=="0" and k==0 and i==f):
                list += ":"            
            if (i == f):
                list += ":"
            else:
                list += parts[i] + ":"
    else:
        for i in range(len(parts)):
            list += str(parts[i]) + ":"
    return list[:-1]
def normalizer_ipv6(address):
    norm_1 = normalize_ipv6_1(address)
    norm_2 = normalizer_ipv6_2(norm_1)
    return norm_2

user_input = input("Введите IPv6 адрес: ")
normalized_user_input = normalizer_ipv6(user_input)
print(normalized_user_input)
with open("ip-addresses4.txt", "r") as log_file:
    ip_addresses = [normalizer_ipv6(line.strip()) for line in log_file.readlines()]
with open("ip_solve.txt", "w") as output_file:
    for address in ip_addresses:
        if normalized_user_input == address:
            output_file.write(f"{user_input} совпадает с {address}\n")
print("Результат записан в ip_solve.txt")