import os
import random

# Создаем директорию "example" в текущей директории проекта
os.mkdir("example")

# Переходим в директорию "example"
os.chdir("example")

# Генерируем и записываем 100 файлов
for i in range(1, 101):
    # Генерируем случайный размер файла от 1 Кб до 100 Кб
    file_size = random.randint(1, 100) * 1024  # размер в байтах

    # Генерируем случайное содержимое файла
    file_content = os.urandom(file_size)

    # Создаем и записываем файл
    with open(f"file_{i}.bin", "wb") as file:
        file.write(file_content)

# Возвращаемся в исходную директорию
os.chdir("..")