with open('orders.csv', 'r') as orders_file, open('analytics.csv', 'w') as analytics_file:
    analytics_file.write('ID Клиента;Общая сумма;Любимый товар\n')
    client_data = {}
    orders_file.readline()
    for line in orders_file:
        list = line.strip().split(';')
        client_id = list[0]
        product_id = list[1]
        price = float(list[2])
        if client_id in client_data:
            client_data[client_id][0] += price
            if product_id in client_data[client_id][1]:
                client_data[client_id][1][product_id] += 1
            else:
                client_data[client_id][1][product_id] = 1
        else:
            client_data[client_id] = [price, {product_id: 1}]

    # Записываем информацию о клиентах в analytics.csv
    for client_id, data in client_data.items():
        total_price = data[0]
        favorite_product = max(data[1], key=data[1].get)
        analytics_file.write(f'{client_id};{total_price:.2f};{favorite_product}\n')

# Завершаем работу с файлами
orders_file.close()
analytics_file.close()