import os

N = input("left:")
K = input("right")
f = 0

os.chdir("example")
path = os.getcwd()

with os.scandir(path) as listOfEntries:  
    for entry in listOfEntries:
        if entry.is_file():
            size_file = (os.stat(entry).st_size)/1024
            if ((size_file)>=float(N) and (size_file)<=float(K)):
                f+=1
                print(entry.name, "=", (os.stat(entry).st_size)/1024)
    print(f)