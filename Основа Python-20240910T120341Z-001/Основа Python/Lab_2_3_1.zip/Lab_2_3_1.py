import random
n = 100000
ip_adress = set()
for k in range(n):
    list = ""
    for i in range(8):
        block = ""
        for j in range(2):
            list1 = random.choice("0123456789abcdf")
            list2 = random.choice("0123456789abcdf")
            block += str(list1) + str(list2)
        list += block + ":"
    ip_adress.add(list[:-1])
print(ip_adress)
with open("ip-addresses4.txt", "w") as file:
   for list in ip_adress:
        file.write(list + "\n")
   file.write(f"сгенерирован {n} количество уникальных IP адресов\n")
print("Генерация завершен ")