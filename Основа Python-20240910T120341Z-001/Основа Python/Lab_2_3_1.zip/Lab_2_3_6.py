# Открываем файл для чтения
with open('article_eng.txt', 'r') as file:
    text = file.read()

# Преобразуем текст в нижний регистр, чтобы учитывать буквы без учета регистра
text = text.lower()

# Создаем словарь для подсчета частот букв
letter_count = {}

# Проходим по каждому символу в тексте
for char in text:
    # Проверяем, является ли символ латинской буквой
    if char.isalpha() and char.isascii():
        if char in letter_count:
            letter_count[char] += 1
        else:
            letter_count[char] = 1

# Общее количество букв в тексте
total_letters = sum(letter_count.values())

# Сортируем буквы по убыванию частоты
sorted_letter_count = sorted(letter_count.items(), key=lambda x: x[1], reverse=True)

# Создаем и записываем результаты в файл article_eng_solve.txt
with open('article_eng_solve.txt', 'w') as output_file:
    for letter, count in sorted_letter_count:
        frequency = count / total_letters
        output_file.write(f'{letter}: {frequency:.3f}\n')